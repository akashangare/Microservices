package com.example.discoveryRegistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoveryRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoveryRegistryApplication.class, args);
	}

}
